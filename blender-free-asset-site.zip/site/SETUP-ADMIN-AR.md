# تشغيل لوحة الإدارة على GitHub Pages

الموقع (index.html + script.js) يقرأ بيانات المنتجات من `data/products.json`.
لوحة الإدارة (`admin/`) هي Decap CMS، وتسمح لك تضيف/تعدّل/تحذف المنتجات من متصفحك
بدون لمس الكود، وكل تعديل ينحفظ كـ commit في مستودع GitHub تبعك.

بما إن GitHub Pages يخدم ملفات ثابتة بس (بدون سيرفر)، نحتاج "بروكسي" بسيط
لعملية تسجيل الدخول (OAuth) مع GitHub — هذا اللي يسويه ملف
`oauth-worker/worker.js` عن طريق Cloudflare Workers (مجاني بالكامل).

## الخطوات

### 1) ارفع الملفات على GitHub
- سوّ مستودع (repo) جديد على GitHub، وارفع كل محتويات هذا المجلد فيه
  (`index.html`, `script.js`, `data/`, `admin/`, `assets/`).
- فعّل GitHub Pages: Settings → Pages → Branch: `main` → Save.
- بعدها موقعك راح يكون على:
  `https://YOUR_USERNAME.github.io/YOUR_REPO/`

### 2) سوّ GitHub OAuth App
- روح على: https://github.com/settings/developers → **New OAuth App**
- **Homepage URL**: `https://YOUR_USERNAME.github.io/YOUR_REPO`
- **Authorization callback URL**: `https://YOUR-WORKER-SUBDOMAIN.workers.dev/callback`
  (بتحصل على الرابط الصح بالخطوة الجاية، ارجع عدّله بعدين لو تغيّر)
- بعد الإنشاء، انسخ **Client ID**، وسوّ **Generate a new client secret** وانسخه.

### 3) انشر الـ OAuth Worker على Cloudflare (مجاني)
- سوّ حساب على https://dash.cloudflare.com (لو ما عندك)
- Workers & Pages → Create → **Create Worker**
- امسح الكود الافتراضي، والصق محتوى `oauth-worker/worker.js` كامل، ثم **Deploy**
- بعد النشر بتشوف رابط شبيه بـ: `https://your-worker-name.your-subdomain.workers.dev`
- روح Settings → Variables and Secrets لهذا الـ Worker، وضيف:
  - `GITHUB_CLIENT_ID` = (من الخطوة 2)
  - `GITHUB_CLIENT_SECRET` = (من الخطوة 2)
- ارجع لصفحة الـ OAuth App بالخطوة 2 وتأكد إن الـ callback URL مطابق تمامًا لرابط الـ Worker + `/callback`

### 4) عدّل `admin/config.yml`
افتح الملف وغيّر هذي الأسطر بمعلوماتك:
```yaml
backend:
  name: github
  repo: YOUR_GITHUB_USERNAME/YOUR_REPO_NAME
  branch: main
  base_url: https://your-worker-name.your-subdomain.workers.dev
  auth_endpoint: auth
```
ارفع (commit) هذا التعديل على GitHub.

### 5) افتح لوحة الإدارة
روح إلى:
`https://YOUR_USERNAME.github.io/YOUR_REPO/admin/`

بيطلب منك تسجيل دخول بحساب GitHub (لازم يكون عندك صلاحية Write على المستودع).
بعد الدخول بتشوف قائمة "Product Library" وتقدر تضيف/تعدّل منتجاتك (Blender assets)،
كل منتج فيه: العنوان، الوصف، الفئة، صورة مصغّرة، إصدار Blender، محرك الرندر،
حجم الملف، الترخيص، رابط الراعي (Monetag/Adsterra)، ورابط Google Drive الحقيقي.

كل حفظ من لوحة الإدارة ينحفظ مباشرة بملف `data/products.json`، والموقع
يقرأه تلقائيًا بدون أي خطوة بناء (build).

---

## ملاحظات مهمة
- الصور اللي ترفعها من لوحة الإدارة تنحط بمجلد `assets/uploads/`.
- خلّي `Client Secret` تبع GitHub OAuth App سري — لا تحطه بأي ملف عام،
  هو موجود بس كـ secret داخل إعدادات الـ Worker.
- إذا ما بترفع أصول جديدة كثير وتفضّل شي أبسط بدون كل خطوات الـ OAuth،
  بديل سريع هو تستضيف بس لوحة الإدارة على Netlify (مجاني) مع Identity +
  Git Gateway — أسهل بخطوتين بس الموقع نفسه يضل على GitHub Pages. قول لي
  إذا تبي أجهز لك هذا البديل بدل Cloudflare Worker.
